from django.db import models
from django.contrib.auth.models import User  # Replace 'your_app' with the actual app na
class Profile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    friends = models.ManyToManyField(User, related_name='friends', blank=True)
    # Other fields...
class Message(models.Model):
    user = models.ForeignKey(User, related_name='sent_messages', on_delete=models.CASCADE)
    recipient = models.ForeignKey(User, related_name='received_messages', on_delete=models.CASCADE)
    content = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.user.username} to {self.recipient.username}: {self.content}"
class Post(models.Model):
    title = models.CharField(max_length=200, default='Default Title')  # Ensure a default
    content = models.TextField()

    def __str__(self):
        return self.title

class MediaItem(models.Model):
    MEDIA_TYPES = (
        ('image', 'Image'),
        ('video', 'Video'),
    )

    title = models.CharField(max_length=100)
    description = models.TextField(blank=True)
    file = models.FileField(upload_to='media/')
    type = models.CharField(max_length=10, choices=MEDIA_TYPES)

    def __str__(self):
        return self.title